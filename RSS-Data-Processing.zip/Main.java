import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.io.*;

class Main {
  public static void main(String[] args) throws IOException {
    File file = new File("data.txt");
    PrintWriter pw = new PrintWriter(file);
    pw.println(
        "All Active Incidents en-us Mon, 01 Feb 2021 17:17:41 -0500 Copyright 511nj.org 1 NYSDOT - Region 11: Watermain break on LEXINGTON AVE southbound E 81ST ST (New York) to E 79TH ST (New York) All lanes closed until further notice Sat, 30 Jan 2021 23:23:48 -0500 40.7762047933386 -73.9579940547879 NYSTA - Statewide Ops.: speed restriction on I-87 - NYS Thruway both directions from Before Exit 10 (I-87) - South Nyack (US 9W) to After Exit 9 (I-87) - Tarrytown (Rte 9); 45mph starting 10:31 PM, 01/31/2021 [CARS CAD-210310409] Sun, 31 Jan 2021 22:31:37 -0500 41.074814 -73.919881 NJ DOT - STMC: Disabled vehicle on I-280 westbound ramp to southbound Exit 8 - CR 577 (West Orange Twp) All lanes closed Mon, 01 Feb 2021 13:35:00 -0500 40.7976850863146 -74.2524416539672 NJ Turnpike Auth.: Crash and Crash with Property Damage on New Jersey Turnpike Outer Roadway northbound North of Interchange 7A - I-195 (Robbinsville) 1 Left lane of 3 lanes blocked Mon, 01 Feb 2021 13:55:22 -0500 40.1916790096157 -74.6032818059683 NYSDOT - Region 3: Disabled vehicle on I-690 eastbound before Exit 11 and Exit 12 - West Street Arterial; West Genesee Street (Syracuse) 1 Left lane of 4 lanes closed Mon, 01 Feb 2021 16:10:46 -0500 43.0552805630482 -76.1630045982268 NYSDOT TMC - Albany: Crash on I-787 southbound at Southern Boulevard; US 9W (Albany) 1 Left lane and shoulder of 2 lanes closed Mon, 01 Feb 2021 16:31:49 -0500 42.6336610336685 -73.7752945614335 NYSDOT TMC - Albany: Crash on I-87 Northway southbound between Exit 33; US 9; NY 22; Essex Ferry (Chesterfield) 2 Right lanes of 3 lanes closed Mon, 01 Feb 2021 16:36:58 -0500 44.4388652456111 -73.4923666848601 NYSTA - Statewide Ops.: crash on I-87 - NYS Thruway southbound at After Exit 21B (I-87) - Coxsackie (Rte 9W - Rte 81) starting 4:37 PM, 02/01/2021 [CARS CAD-210320314] Mon, 01 Feb 2021 16:37:29 -0500 42.425971 -73.805389 NYSTA - Statewide Ops.: disabled truck ,right lane blocked on I-87 - NYS Thruway northbound at After Exit 14B (I-87) - Airmont Rd starting 4:41 PM, 02/01/2021 [CARS NYSTA4-5668] Mon, 01 Feb 2021 16:41:46 -0500 41.116889 -74.114353 NYSDOT - Region 11: Disabled vehicle on I-495 eastbound at START ROUTE I-495 Exit- Queens Midtown Tunnel 2nd Avenue East 36th Street (New York) 1 Right lane of 2 lanes blocked Mon, 01 Feb 2021 16:48:18 -0500 40.7457926607428 -73.9743054452554 NJ DOT - STMC: Disabled tractor trailer on I-80 eastbound East of Exit 4 - NJ 94/US 46 (Knowlton Twp) 1 Right lane of 4 lanes closed Mon, 01 Feb 2021 16:48:39 -0500 40.9297759864187 -75.0761901188364 NYSTA - Statewide Ops.: crash on I-87 - NYS Thruway northbound at After Exit 21B (I-87) - Coxsackie (Rte 9W - Rte 81) starting 4:49 PM, 02/01/2021 [CARS CAD-210320324] Mon, 01 Feb 2021 16:49:04 -0500 42.425971 -73.805389 NYSTA - Statewide Ops.: crash on I-90 - NYS Thruway westbound at Before Exit 44 (I-90) - Canandaigua (Rte 332) starting 4:50 PM, 02/01/2021 [CARS CAD-210320326] Mon, 01 Feb 2021 16:50:04 -0500 42.995125 -77.355153 NJ Turnpike Auth.: Crash on Garden State Parkway southbound North of Exit 77 - Berkeley (Berkeley Twp) All lanes open Mon, 01 Feb 2021 16:56:20 -0500 39.9064113103176 -74.2124400988919 NYSDOT - Region 3: Crash on I-81 northbound at I-690 West (Syracuse) 1 Left lane of 3 lanes closed Mon, 01 Feb 2021 17:01:33 -0500 43.0514276053197 -76.1457931529821 NJ DOT - TOC South: Jack-knifed tractor trailer on I-295 northbound South of Exit 28 - NJ 168/Black Horse Pike (Bellmawr) 1 Left lane of 4 lanes closed use caution Mon, 01 Feb 2021 17:11:38 -0500 39.8720755003013 -75.0862657429192 NJ Turnpike Auth.: Crash and Crash with Property Damage on New Jersey Turnpike Outer Roadway southbound North of Interchange 9 - NJ 18 (Edison Twp) All lanes open to traffic Mon, 01 Feb 2021 17:12:14 -0500 40.4885118705602 -74.396486275174 NJ DOT - TOC South: Crash on I-295 northbound South of Exit 56 - US 206 (Mansfield Twp) right shoulder closed use caution Mon, 01 Feb 2021 17:12:57 -0500 40.1102801514191 -74.7340988706631 NYSDOT - Region 8: Crash with property damage on NY 55 westbound at Hall Dr (La Grange) right shoulder of 1 lane blocked Mon, 01 Feb 2021 16:13:34 -0500 41.6367027602345 -73.7118633558197 South Jersey Transp. Auth.: Emergency construction on Atlantic City Expressway ramp from Exit 2 - US 322 (Atlantic City) All lanes closed 'FOLLOW DETOUR TO RTE 9, TO UTILIZE EXIT #5 FOR THE EXPRESSWAY WESTBOUND' Mon, 01 Feb 2021 14:16:58 -0500 39.3772303374459 -74.4793374238098 NYSDOT - Region 11: Sinkhole on FDR DR SERVICE RD E service road northbound at E 34TH ST (New York) All lanes closed until further notice Sun, 24 Jan 2021 05:33:34 -0500 40.7431936165325 -73.9720575136339 NYSDOT - Region 11: Falling Debris on W 58TH ST eastbound 7TH AVE (New York) to 6TH AVE (New York) All lanes closed Thu, 14 Jan 2021 06:27:40 -0500 40.7662045423871 -73.97956085996 NYC DOT: Parking related on New York City (New York) All lanes open Alternate side parking (street cleaning) regulations are suspended Monday, February 1 through Saturday, February 6 for snow operations. All other regulations, including parking meters, remain in effect. All other regulations, including parking meters, remain in effect. Mon, 01 Feb 2021 13:03:04 -0500 40.7831476932736 -73.963788462601 South Jersey Transp. Auth.: Speed restriction on Atlantic City Expressway westbound from Atlantic City Convention Center/Eastern Terminus (Atlantic City) to Western Terminus - NJ 42 (Washington Twp) All lanes open speed limit reduced to 35 MPH use caution Mon, 01 Feb 2021 15:51:24 -0500 39.35992 -74.43834 South Jersey Transp. Auth.: Speed restriction on Atlantic City Expressway eastbound from Western Terminus - NJ 42 (Washington Twp) to Atlantic City Convention Center/Eastern Terminus (Atlantic City) All lanes open speed limit reduced to 35 MPH use caution Mon, 01 Feb 2021 15:51:03 -0500 39.7697795070552 -75.0488727867222 NYSDOT - Region 8: Crash with injuries on I-684 southbound at START ROUTE I-684; Exit 9A -; I-287 (Harrison) right shoulder of 3 lanes blocked MM 1.0 Mon, 01 Feb 2021 11:51:52 -0500 41.021598815918 -73.727897644043 NYSDOT - Region 10: Disabled vehicle on Southern State Parkway westbound between Exit 15 - North Corona Avenue (Hempstead) and Exit 13N - North Central Avenue (Hempstead) right lane closed Mon, 01 Feb 2021 16:58:29 -0500 40.6819000244141 -73.6920013427734 NYSDOT - Region 8: Crash with property damage on NY 343 eastbound west of NY 22 (Amenia) right shoulder of 2 lanes blocked 1297 State Hwy 343 Mon, 01 Feb 2021 17:12:50 -0500 41.8165016174316 -73.563003540039 NJ DOT - STMC: Full Commercial Vehicle Ban on I-78 eastbound Exit 3 - NJ 173/US 22 (Pohatcong Twp) to I-78 Express Lanes at Exit 58 - US 1&9/E. Port St (Newark), Sunday January 31st, 2021 thru Tuesday February 2nd, 2021, Sunday/Monday/Tuesday, 12:00 PM thru 11:59 PM All lanes open Sun, 31 Jan 2021 13:08:55 -0500 40.66971570094 -75.13475289718 NJ DOT - STMC: Full Commercial Vehicle Ban on I-80 eastbound Exit 1 - Delaware Water Gap (Hardwick Twp) to I-80 Local Lanes at Exit 68 - New Jersey Turnpike/I-95 (Teaneck Twp), Sunday January 31st, 2021 thru Wednesday February 3rd, 2021, Sunday/Monday/Tuesday/Wednesday, 12:00 AM thru 11:59 PM All lanes open Sun, 31 Jan 2021 13:24:52 -0500 40.9752956439413 -75.1348322233708 NJ DOT - STMC: Full Commercial Vehicle Ban on I-280 eastbound East of I-80 (Parsippany-Troy Hills Twp) to Exit 18 - New Jersey Turnpike (Kearny), Sunday January 31st, 2021 thru Wednesday February 3rd, 2021, Sunday/Monday/Tuesday/Wednesday, 12:00 AM thru 11:59 PM All lanes open Sun, 31 Jan 2021 13:25:48 -0500 40.85804 -74.36373 NJ DOT - STMC: Full Commercial Vehicle Ban on I-287 northbound North of New Jersey Turnpike (Edison Twp) to New York State Line (Mahwah Twp), Sunday January 31st, 2021 thru Wednesday February 3rd, 2021, Sunday/Monday/Tuesday/Wednesday, 12:00 AM thru 11:59 PM All lanes open Sun, 31 Jan 2021 13:28:35 -0500 40.52902 -74.33896 NJ DOT - STMC: Full Commercial Vehicle Ban on NJ 440 northbound New Jersey Turnpike/I-287 (Edison Twp) to North of CR 653/Amboy Ave (Perth Amboy), Sunday January 31st, 2021 thru Wednesday February 3rd, 2021, Sunday/Monday/Tuesday/Wednesday, 12:00 AM thru 11:59 PM All lanes open Sun, 31 Jan 2021 13:31:22 -0500 40.5283145245028 -74.3368617483427");
    pw.close();
    Scanner scanner = new Scanner(file);
    List<String> incidents = new ArrayList<String>();
    scanner.useDelimiter(" -0500 ");
    while (scanner.hasNext()) {
      incidents.add(scanner.next() + " -0500 ");
    }

    int elements = incidents.size() - 1;
    String dates[] = new String[elements];
    String times[] = new String[elements];
    String events[] = new String[elements];
    String localDate = java.time.LocalDate.now().toString();
    String year = localDate.substring(0, localDate.indexOf("-"));
    for (int i = 0; i < elements; i++) {
      String s = String.valueOf(incidents.get(i));
      int origin = 0;
      for (int j = 0; j < s.length(); j++) {
        if ((j == 0 || j == s.length() - 1) && (int) (s.charAt(j)) < 48 || (int) (s.charAt(j)) > 57) {
          origin = j;
          break;
        }
        if (j > 0 && j < s.length() - 1 && ((int) (s.charAt(j)) < 48 || (int) (s.charAt(j)) > 57)
            && ((int) (s.charAt(j - 1)) < 48 || (int) (s.charAt(j - 1)) > 57)
            && ((int) (s.charAt(j + 1)) < 48 || (int) (s.charAt(j + 1)) > 57)) {
          origin = j;
          break;
        }
      }
      int index = 0;
      if (s.indexOf("Sun,") != -1) {
        index = s.indexOf("Sun,");
      }
      if (s.indexOf("Mon,") != -1) {
        index = s.indexOf("Mon,");
      }
      if (s.indexOf("Tues,") != -1) {
        index = s.indexOf("Tues,");
      }
      if (s.indexOf("Wed,") != -1) {
        index = s.indexOf("Wed,");
      }
      if (s.indexOf("Thu,") != -1) {
        index = s.indexOf("Thu,");
      }
      if (s.indexOf("Fri,") != -1) {
        index = s.indexOf("Fri,");
      }
      if (s.indexOf("Sat,") != -1) {
        index = s.indexOf("Sat,");
      }
      dates[i] = s.substring(index, s.lastIndexOf(year) + 4);
      times[i] = s.substring(s.lastIndexOf(year) + 5, s.indexOf(" -0500 "));
      events[i] = s.substring(origin, index - 1);
      System.out.println("Date: " + dates[i]);
      System.out.println("Time: " + times[i]);
      System.out.println("Event: " + events[i]);
      System.out.println(" ");
    }
  }
}