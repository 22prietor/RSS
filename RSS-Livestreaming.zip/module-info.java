module com.apptastic.rssreader {
    requires java.net.http;
    requires java.xml;
    requires java.logging;
    exports com.apptastic.rssreader;
}
