# Feeder
Simple RSS reader written in Java.

My first project in Java. Written in June/May 2016 as a project for Event-driven programming course at Warsaw University of Technology.
