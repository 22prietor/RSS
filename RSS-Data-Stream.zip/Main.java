import java.util.Scanner;
import java.io.*; //all input output stuff including File and all exceptions

class Main {
  public static void main(String[] args) throws IOException {
    File file = new File("data.txt"); 
    PrintWriter pw = new PrintWriter(file);
    pw.println("All Active Incidents en-us Sat, 16 Jan 2021 23:09:26 -0500 Copyright 511nj.org 1 NYSDOT - Region 11: Sinkhole on FDR DR SERVICE RD E service road northbound at E 34TH ST (New York) All lanes closed until further notice Thu, 07 Jan 2021 15:38:12 -0500 40.7431936165325 -73.9720575136339 NYSDOT TMC - Albany: Disabled vehicle on I-87 Northway southbound at Exit 21: NY 9N (Lake George) right shoulder closed Sat, 16 Jan 2021 22:38:05 -0500 43.39927 -73.71184 NYSDOT - Region 11: Crash on I-495 westbound at Exit 27 - Clearview Expwy I-295 / Throgs Neck Bridge (New York) 2 Left lanes of 3 lanes closed Sat, 16 Jan 2021 23:00:02 -0500 40.7433990633634 -73.7757620247744 NYSDOT - Region 11: Crash on Franklin D. Roosevelt Drive southbound at East 91st Street (New York) 2 Left lanes of 3 lanes closed Sat, 16 Jan 2021 23:04:49 -0500 40.763570764595 -73.9535142348365 NYSDOT - Region 11: Fire department activity on I-495 westbound at Exit 27 - Clearview Expwy I-295 / Throgs Neck Bridge (New York) 1 Right lane of 4 lanes closed Sat, 16 Jan 2021 23:06:38 -0500 40.7431455097784 -73.7775423498476 NYSDOT - Region 2: Truck restrictions on NY 334 both directions between West Main Street; NY 5; START ROUTE NY 334 (Mohawk) and Town of Johnstown; Town of Mohawk Line (Mohawk) 12.0 foot height restriction under railroad bridge Fri, 08 Jan 2021 10:37:49 -0500 42.9585210994617 -74.3935857595253 NYSDOT - Region 8: Crash with property damage on NY 22 northbound at Old Post Road; Old NY 22 (North Castle) right shoulder of 2 lanes blocked Sat, 16 Jan 2021 22:39:30 -0500 41.1157989501953 -73.7202987670898 NYSDOT - Region 10: Crash on NY 454 eastbound at State Office Building (Suffolk) left and center lanes closed Sat, 16 Jan 2021 22:40:40 -0500 40.8243 -73.2217 South Jersey Transp. Auth.: Emergency construction on Atlantic City Expressway ramp from Exit 2 - US 322 (Atlantic City) All lanes closed 'FOLLOW DETOUR TO RTE 9, TO UTILIZE EXIT #5 FOR THE EXPRESSWAY WESTBOUND' Sat, 16 Jan 2021 22:15:29 -0500 39.3772303374459 -74.4793374238098 NYSDOT - Region 11: Falling Debris on W 58TH ST eastbound 7TH AVE (New York) to 6TH AVE (New York) All lanes closed Thu, 14 Jan 2021 06:27:40 -0500 40.7662045423871 -73.97956085996 ConnDOT: Motor Vehicle Accident (2 Vehicle) on RT15 Southbound between Exits 66 and 65. The left lane is closed. Reported Saturday, January 16 at 9:41 pm. Sat, 16 Jan 2021 22:59:38 -0500 41.467338 -72.830538 NJ DOT - STMC: Crash investigation on US 9 northbound Ryan Rd/Symmes Rd (Manalapan Twp) All lanes closed 5 minute delay Sat, 16 Jan 2021 21:58:18 -0500 40.2927308316716 -74.2980234770471");
    pw.close();
    Scanner scanner = new Scanner(file);
    scanner.useDelimiter("-0500"); 	  
    while (scanner.hasNext()) { 
      String s = "-0500" + scanner.next();
      if (s.toLowerCase().contains("flood")) {
      System.out.println(s);
      }
    }
    scanner.close();
  }
}